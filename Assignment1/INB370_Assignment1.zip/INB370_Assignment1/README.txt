This folder contains all the material to be zipped and put on BB for the
students, i.e., the written instructions (PDF), the API specification
(JavaDoc) and the GUI code they need to interface with (Java).

Two additional documents, the marking template and submission guidelines
are not included here, but their source can be found in the ass1-instructions-source folder.
